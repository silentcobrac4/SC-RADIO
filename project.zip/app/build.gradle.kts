plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sc.radio"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sc.radio"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2.0"
    }
    signingConfigs {
        create("rel") {
            storeFile = rootProject.file("sc-radio.jks")
            storePassword = "scradio123"
            keyAlias = "sc"
            keyPassword = "scradio123"
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("rel")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
