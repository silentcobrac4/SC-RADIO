package com.sc.radio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/** Draws the whole radio with Canvas (no image files) and reports key presses. */
class RadioView(c: Context) : View(c) {
    interface Cb {
        fun onPtt(down: Boolean)
        fun onKey(id: String)
    }

    var cb: Cb? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rects = LinkedHashMap<String, RectF>()
    private var pressed: String? = null
    private var w = 0f
    private var h = 0f

    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        w = nw.toFloat(); h = nh.toFloat()
        rects.clear()
        fun r(id: String, l: Float, t: Float, rt: Float, b: Float) {
            rects[id] = RectF(l * w, t * h, rt * w, b * h)
        }
        fun circ(id: String, cx: Float, cy: Float, rad: Float) {
            rects[id] = RectF(cx * w - rad * w, cy * h - rad * w, cx * w + rad * w, cy * h + rad * w)
        }
        r("users", .07f, .035f, .50f, .080f)
        r("mode", .33f, .175f, .67f, .222f)
        circ("power", .19f, .295f, .06f)
        circ("red", .81f, .295f, .05f)
        r("minus", .17f, .380f, .37f, .430f)
        r("m", .40f, .380f, .60f, .430f)
        r("plus", .63f, .380f, .83f, .430f)
        r("up", .17f, .445f, .37f, .495f)
        r("scan", .40f, .445f, .60f, .495f)
        r("dn", .63f, .445f, .83f, .495f)
        r("ptt", .14f, .790f, .86f, .930f)
    }

    private fun fill(c: Int) { p.style = Paint.Style.FILL; p.color = c; p.shader = null }
    private fun stroke(c: Int, wd: Float) { p.style = Paint.Style.STROKE; p.color = c; p.strokeWidth = wd; p.shader = null }

    private fun text(s: String, x: Float, cy: Float, size: Float, color: Int, al: Paint.Align) {
        fill(color)
        p.textAlign = al
        p.textSize = size
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        cv0.drawText(s, x, cy - (p.descent() + p.ascent()) / 2f, p)
    }

    private lateinit var cv0: Canvas

    private fun key(id: String, label: String, on: Boolean) {
        val r = rects[id] ?: return
        val u = w / 100f
        fill(if (pressed == id) 0xFF55555A.toInt() else 0xFF2B2B2E.toInt())
        cv0.drawRoundRect(r, 2.5f * u, 2.5f * u, p)
        stroke(0xFF626266.toInt(), .4f * u)
        cv0.drawRoundRect(r, 2.5f * u, 2.5f * u, p)
        text(label, r.centerX(), r.centerY(), 4.4f * u, if (on) 0xFFE6E6E6.toInt() else 0xFF6A6A6E.toInt(), Paint.Align.CENTER)
    }

    override fun onDraw(cv: Canvas) {
        cv0 = cv
        val on = Engine.on
        val u = w / 100f
        cv.drawColor(Color.BLACK)

        // antenna + knob
        fill(0xFF1F1F22.toInt())
        cv.drawRoundRect(RectF(.66f * w, .045f * h, .78f * w, .17f * h), 2 * u, 2 * u, p)
        cv.drawRoundRect(RectF(.20f * w, .105f * h, .34f * w, .17f * h), 2 * u, 2 * u, p)

        // body
        val body = RectF(.07f * w, .15f * h, .93f * w, .965f * h)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, body.top, 0f, body.bottom, 0xFF3D3D41.toInt(), 0xFF17171A.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(body, 9 * u, 9 * u, p)
        stroke(0xFF5A5A5E.toInt(), .5f * u)
        cv.drawRoundRect(body, 9 * u, 9 * u, p)

        // online users label
        text("Online Users=${Engine.onlineCount()}", .07f * w, .0575f * h, 3.8f * u, 0xFF3DDC84.toInt(), Paint.Align.LEFT)

        // mode badge
        rects["mode"]?.let { r ->
            fill(if (on) 0xFF1E4620.toInt() else 0xFF1A2A1B.toInt())
            cv.drawRoundRect(r, r.height() / 2, r.height() / 2, p)
            text(if (Engine.mode == 1) "PRIVATE" else "NEARBY", r.centerX(), r.centerY(), 3.6f * u,
                if (on) 0xFF9CF59F.toInt() else 0xFF4D6B4E.toInt(), Paint.Align.CENTER)
        }

        // LCD
        val lcd = RectF(.28f * w, .24f * h, .72f * w, .35f * h)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, lcd.top, 0f, lcd.bottom,
            if (on) 0xFFF4B73A.toInt() else 0xFF2E2E24.toInt(),
            if (on) 0xFFD9951A.toInt() else 0xFF202018.toInt(), Shader.TileMode.CLAMP
        )
        cv.drawRoundRect(lcd, 2 * u, 2 * u, p)
        stroke(0xFF0B0B0C.toInt(), .9f * u)
        cv.drawRoundRect(lcd, 2 * u, 2 * u, p)
        if (on) {
            val ink = 0xFF2B1A00.toInt()
            text("CH", lcd.left + 3 * u, lcd.top + 4.2f * u, 3f * u, ink, Paint.Align.LEFT)
            text("LINK ${Engine.linkCount()}", lcd.right - 3 * u, lcd.top + 4.2f * u, 3f * u, ink, Paint.Align.RIGHT)
            text("%02d".format(Engine.channel), lcd.centerX(), lcd.centerY() - 0.5f * u, minOf(lcd.height() * .55f, 17 * u), ink, Paint.Align.CENTER)
            val st = when {
                Engine.talking -> "TX"
                Engine.rxActive -> ("RX " + Engine.rxName).take(11)
                Engine.scanning -> "SCAN"
                else -> "READY"
            }
            text(st, lcd.centerX(), lcd.bottom - 4f * u, 3.2f * u, ink, Paint.Align.CENTER)
            for (i in 0 until 5) {
                val x = lcd.left + 3 * u + i * 2.4f * u
                val bh = (1 + i) * 0.9f * u
                fill(if (Engine.volume >= (i + 1) * 2) ink else 0x332B1A00)
                cv.drawRect(x, lcd.bottom - 3 * u - bh, x + 1.6f * u, lcd.bottom - 3 * u, p)
            }
        }

        // power button
        rects["power"]?.let { r ->
            val rad = r.width() / 2
            fill(if (pressed == "power") 0xFF3A3A3E.toInt() else 0xFF222225.toInt())
            cv.drawCircle(r.centerX(), r.centerY(), rad, p)
            val col = if (on) 0xFF2979FF.toInt() else 0xFF22335F.toInt()
            stroke(col, .9f * u)
            cv.drawCircle(r.centerX(), r.centerY(), rad, p)
            stroke(col, 1.0f * u)
            p.strokeCap = Paint.Cap.ROUND
            cv.drawArc(RectF(r.centerX() - rad * .45f, r.centerY() - rad * .45f, r.centerX() + rad * .45f, r.centerY() + rad * .45f), -60f, 300f, false, p)
            cv.drawLine(r.centerX(), r.centerY() - rad * .55f, r.centerX(), r.centerY() - rad * .05f, p)
            p.strokeCap = Paint.Cap.BUTT
            text("PWR", r.centerX(), r.bottom + 2.6f * u, 2.6f * u, 0xFF8A8A8E.toInt(), Paint.Align.CENTER)
        }

        // red message button
        rects["red"]?.let { r ->
            val rad = r.width() / 2
            fill(if (pressed == "red") 0xFFFF6B6B.toInt() else if (on) 0xFFD32F2F.toInt() else 0xFF5A1A1A.toInt())
            cv.drawCircle(r.centerX(), r.centerY(), rad, p)
            stroke(0xFF1A1A1C.toInt(), .6f * u)
            cv.drawCircle(r.centerX(), r.centerY(), rad, p)
            text("MSG", r.centerX(), r.bottom + 2.6f * u, 2.6f * u, 0xFF8A8A8E.toInt(), Paint.Align.CENTER)
        }

        // keys
        key("minus", "VOL -", on)
        key("m", "M", on)
        key("plus", "VOL +", on)
        key("up", "UP", on)
        key("scan", "SCAN", on)
        key("dn", "DN", on)

        // speaker grille
        val gr = RectF(.16f * w, .525f * h, .84f * w, .775f * h)
        fill(0xFF101012.toInt())
        cv.drawRoundRect(gr, 4 * u, 4 * u, p)
        stroke(0xFF2F2F33.toInt(), 1.5f * u)
        p.strokeCap = Paint.Cap.ROUND
        val n = 9
        for (i in 0 until n) {
            val y = gr.top + (i + 1) * gr.height() / (n + 1)
            cv.drawLine(gr.left + 5 * u, y, gr.right - 5 * u, y, p)
        }
        p.strokeCap = Paint.Cap.BUTT

        // PTT
        rects["ptt"]?.let { r ->
            val base = when {
                !on -> 0xFF222224.toInt()
                Engine.talking || pressed == "ptt" -> 0xFFC62828.toInt()
                Engine.rxActive -> 0xFF2E7D32.toInt()
                else -> 0xFF3A3A3E.toInt()
            }
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, r.top, 0f, r.bottom, base, 0xFF101012.toInt(), Shader.TileMode.CLAMP)
            cv.drawRoundRect(r, 7 * u, 7 * u, p)
            stroke(0xFF68686C.toInt(), .5f * u)
            cv.drawRoundRect(r, 7 * u, 7 * u, p)
            text("PTT", r.centerX(), r.centerY(), 10 * u, if (on) 0xFFF0F0F0.toInt() else 0xFF6A6A6E.toInt(), Paint.Align.CENTER)
        }
    }

    private fun hit(x: Float, y: Float): String? {
        for ((id, r) in rects) if (r.contains(x, y)) return id
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val id = hit(e.x, e.y)
                pressed = id
                if (id != null) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    if (id == "ptt") cb?.onPtt(true)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val id = pressed
                pressed = null
                if (id == "ptt") cb?.onPtt(false)
                else if (id != null && id == hit(e.x, e.y)) cb?.onKey(id)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                if (pressed == "ptt") cb?.onPtt(false)
                pressed = null
                invalidate()
            }
        }
        return true
    }
}
