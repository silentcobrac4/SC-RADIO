package com.sc.radio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.UUID
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt

class Link(
    val sock: BluetoothSocket,
    val remoteId: Int,
    val outgoing: Boolean,
    val addr: String,
    val inp: DataInputStream
) {
    val q = ArrayBlockingQueue<ByteArray>(80)
    @Volatile var alive = true
    fun close() {
        alive = false
        try { sock.close() } catch (e: Exception) {}
    }
}

class User(val name: String, @Volatile var ts: Long, val hops: Int)

class Fav(val name: String, val ch: Int, val mode: Int, val pass: String)

/**
 * Bluetooth mesh radio. Every radio keeps RFCOMM links to a few neighbours and floods
 * packets (with de-duplication) so up to ~10 radios can hear each other.
 */
@SuppressLint("MissingPermission")
object Engine {
    const val T_AUDIO = 1          // 8 kHz mu-law, 160 bytes
    const val T_TEXT = 2
    const val T_HELLO = 3
    const val T_END = 4
    const val T_AUDIO16 = 5        // 16 kHz mu-law, 320 bytes

    const val RATE = 16000
    const val FRAME = 320          // 20 ms at 16 kHz
    const val LO = 160             // 20 ms at 8 kHz
    const val MAX_LINKS = 7        // Bluetooth piconet limit
    const val OUT_LINKS = 4        // outgoing connections we start by ourselves
    const val TTL = 5
    val SVC: UUID = UUID.fromString("5c0f5a3e-8e4b-4b7a-9d52-5c7ad10c0001")

    // option switches (settings screen)
    const val O_ENH = 0
    const val O_HIQ = 1
    const val O_SPWR = 2
    const val O_SROG = 3
    const val O_SCLK = 4
    const val O_LED = 5
    const val O_METER = 6
    const val O_GLOW = 7
    const val O_VIB = 8
    const val O_SIG = 9
    const val O_LOCK = 10
    const val NOPT = 11
    val opt = BooleanArray(NOPT) { true }
    fun flag(i: Int): Boolean = opt[i]

    private lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    var onChange: (() -> Unit)? = null
    var onText: ((String) -> Unit)? = null

    @Volatile var on = false
    @Volatile var channel = 1
    @Volatile var mode = 0            // 0 = nearby (open), 1 = private (passcode)
    @Volatile var passcode = ""
    @Volatile var voice = 0           // 0 normal, 1 hi, 2 low
    @Volatile var volume = 7
    @Volatile var scanning = false
    @Volatile var talking = false
    @Volatile var rxActive = false
    @Volatile var rxName = ""
    @Volatile var rxHops = 1
    @Volatile var searching = false
    @Volatile var busyUntil = 0L
    @Volatile var micErr = 0L
    @Volatile var level = 0f
    @Volatile var unread = 0
    @Volatile var locked = false
    @Volatile var callsign = "SC-0000"
    @Volatile private var rxLast = 0L
    @Volatile private var rxSender = 0
    @Volatile private var txGen = 0
    @Volatile private var lastLvlUi = 0L
    private val micLock = Any()
    private var nodeId = 0
    private var seq = 0

    val users = ConcurrentHashMap<Int, User>()
    val favs = ArrayList<Fav>()
    private val chat = ArrayList<String>()

    private val pool = Executors.newCachedThreadPool()
    private val connector = Executors.newSingleThreadExecutor()
    private val links = ArrayList<Link>()
    private val connecting = HashSet<String>()
    private val backoff = HashMap<String, LongArray>()
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val seen = object : LinkedHashMap<Long, Boolean>() {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Boolean>?): Boolean = size > 4096
    }
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothServerSocket? = null
    private var wl: PowerManager.WakeLock? = null
    private var recv: BroadcastReceiver? = null
    @Volatile private var running = false
    @Volatile private var gen = 0

    private val pq = ArrayBlockingQueue<ShortArray>(120)
    private var track: AudioTrack? = null
    private var tg: ToneGenerator? = null

    private var keyPass = ""
    private var keyBytes = ByteArray(16)

    // ---------------------------------------------------------------- setup / prefs

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs = ctx.getSharedPreferences("sc", Context.MODE_PRIVATE)
        channel = prefs.getInt("ch", 1).coerceIn(1, 99)
        mode = prefs.getInt("mode", 0)
        passcode = prefs.getString("pass", "") ?: ""
        if (mode == 1 && passcode.isEmpty()) mode = 0
        voice = prefs.getInt("voice", 0)
        volume = prefs.getInt("vol", 7).coerceIn(0, 10)
        val o = prefs.getString("opts", null)
        if (o != null) for (i in 0 until NOPT) if (i < o.length) opt[i] = o[i] == '1'
        loadFavs()
        val cs = prefs.getString("call", null)
        callsign = cs ?: ("SC-" + (1000 + Random().nextInt(9000)))
        if (cs == null) prefs.edit().putString("call", callsign).apply()
        nodeId = prefs.getInt("node", 0)
        if (nodeId == 0) {
            nodeId = Random().nextInt() or 1
            prefs.edit().putInt("node", nodeId).apply()
        }
        seq = Random().nextInt()
    }

    private fun save() {
        prefs.edit().putInt("ch", channel).putInt("mode", mode).putString("pass", passcode)
            .putInt("voice", voice).putInt("vol", volume).putString("call", callsign)
            .putString("opts", opt.joinToString("") { if (it) "1" else "0" }).apply()
    }

    private fun loadFavs() {
        try {
            val a = JSONArray(prefs.getString("favs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                favs.add(Fav(o.getString("n"), o.getInt("c"), o.getInt("m"), o.getString("p")))
            }
        } catch (e: Exception) {}
    }

    private fun saveFavs() {
        val a = JSONArray()
        for (f in favs) a.put(JSONObject().put("n", f.name).put("c", f.ch).put("m", f.mode).put("p", f.pass))
        prefs.edit().putString("favs", a.toString()).apply()
    }

    fun changed() { ui.post { onChange?.invoke() } }
    private fun now() = System.currentTimeMillis()
    private fun alive(g: Int) = running && g == gen
    private fun nap(g: Int, ms: Long) {
        var t = 0L
        while (t < ms && alive(g)) { Thread.sleep(200); t += 200 }
    }

    // ---------------------------------------------------------------- user actions

    fun gotoChannel(c: Int) {
        channel = ((c - 1 + 99) % 99) + 1
        scanning = false
        users.clear()
        save(); changed()
        if (on) {
            if (opt[O_SCLK]) tone(ToneGenerator.TONE_PROP_BEEP, 40)
            pool.execute { sendHello() }
        }
    }

    fun step(d: Int) = gotoChannel(channel + d)

    fun setMode(m: Int, pass: String) {
        mode = m; passcode = if (m == 1) pass else ""
        users.clear()
        save(); changed()
        if (on) pool.execute { sendHello() }
    }

    fun chooseVoice(v: Int) { voice = v; save(); changed() }

    fun changeVolume(v: Int) {
        volume = v.coerceIn(0, 10)
        track?.setVolume(volume / 10f)
        save(); changed()
    }

    fun renameSelf(s: String) {
        val t = s.trim().take(14)
        if (t.isEmpty()) return
        callsign = t; save(); changed()
        if (on) pool.execute { sendHello() }
    }

    fun setOpt(i: Int, v: Boolean) {
        opt[i] = v
        if (i == O_LOCK && !v) locked = false
        save(); changed()
    }

    fun toggleScan() {
        if (!on) return
        scanning = !scanning
        changed()
    }

    // favourites ---------------------------------------------------------

    fun addFav(name: String): Boolean {
        val n = name.trim().take(16).ifEmpty { "CH " + "%02d".format(channel) }
        val idx = favs.indexOfFirst { it.ch == channel && it.mode == mode && it.pass == passcode }
        if (idx >= 0) favs[idx] = Fav(n, channel, mode, passcode)
        else {
            if (favs.size >= 9) return false
            favs.add(Fav(n, channel, mode, passcode))
        }
        saveFavs()
        return true
    }

    fun removeFav(i: Int) {
        if (i in favs.indices) { favs.removeAt(i); saveFavs() }
    }

    fun applyFav(i: Int) {
        val f = favs.getOrNull(i) ?: return
        setMode(f.mode, f.pass)
        gotoChannel(f.ch)
    }

    // ---------------------------------------------------------------- info for the UI

    fun linkCount(): Int = synchronized(links) { links.size }
    fun onlineCount(): Int = if (on) 1 + users.size else 0
    fun chatAll(): String = synchronized(chat) { chat.joinToString("\n") }

    private fun addLog(s: String) {
        val t = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        synchronized(chat) {
            chat.add("[$t] $s")
            while (chat.size > 200) chat.removeAt(0)
        }
    }

    fun sendText(t: String) {
        if (!on || t.isBlank()) return
        addLog("أنا: $t")
        val msg = "$callsign: $t"
        pool.execute { send(T_TEXT, msg.toByteArray(Charsets.UTF_8), TTL) }
    }

    // ---------------------------------------------------------------- lifecycle

    fun begin(): Boolean {
        if (running) return true
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) return false
        adapter = ad
        gen++
        val g = gen
        running = true
        on = true
        wl = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "scradio:wl").also { it.acquire() }
        startPlayback(g)
        pool.execute { serverLoop(g) }
        pool.execute { connectLoop(g) }
        pool.execute { tickLoop(g) }
        if (opt[O_SPWR]) tone(ToneGenerator.TONE_PROP_PROMPT, 200)
        changed()
        return true
    }

    fun end() {
        running = false
        on = false; scanning = false; talking = false; rxActive = false; locked = false; level = 0f
        try { server?.close() } catch (e: Exception) {}
        val all = synchronized(links) { val l = ArrayList(links); links.clear(); l }
        all.forEach { it.close() }
        users.clear()
        stopPlayback()
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
        wl = null
        changed()
    }

    // ---------------------------------------------------------------- links

    private fun serverLoop(g: Int) {
        while (alive(g)) {
            try {
                val ss = adapter!!.listenUsingInsecureRfcommWithServiceRecord("scradio", SVC)
                server = ss
                while (alive(g)) {
                    val s = ss.accept()
                    if (linkCount() >= MAX_LINKS) {
                        try { s.close() } catch (e: Exception) {}
                    } else {
                        pool.execute { setup(s, false) }
                    }
                }
                ss.close()
            } catch (e: Exception) {
                try { server?.close() } catch (e2: Exception) {}
                if (alive(g)) Thread.sleep(1500)
            }
        }
    }

    private fun connectLoop(g: Int) {
        while (alive(g)) {
            try {
                val ad = adapter
                if (ad != null && !ad.isDiscovering && linkCount() < OUT_LINKS) {
                    for (d in ad.bondedDevices) tryConnect(d, false)
                }
            } catch (e: Exception) {}
            nap(g, 7000)
        }
    }

    private fun linked(a: String): Boolean = synchronized(links) { links.any { it.addr == a } }

    private fun tryConnect(d: BluetoothDevice, force: Boolean) {
        val a = d.address
        if (d.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.AUDIO_VIDEO) return
        if (linked(a)) return
        if (!force) {
            val wait = synchronized(backoff) { val b = backoff[a]; b != null && now() < b[1] }
            if (wait) return
        }
        val first = synchronized(connecting) { connecting.add(a) }
        if (!first) return
        connector.execute {
            try {
                if (running && !linked(a)) {
                    val s = d.createInsecureRfcommSocketToServiceRecord(SVC)
                    s.connect()
                    synchronized(backoff) { backoff.remove(a) }
                    pool.execute { setup(s, true) }
                }
            } catch (e: Exception) {
                synchronized(backoff) {
                    val b = backoff.getOrPut(a) { longArrayOf(0L, 0L) }
                    b[0] = b[0] + 1
                    b[1] = now() + 10000L * minOf(b[0], 6L)
                }
            } finally {
                synchronized(connecting) { connecting.remove(a) }
            }
        }
    }

    private fun setup(s: BluetoothSocket, outgoing: Boolean) {
        var mine: Link? = null
        try {
            val o = s.outputStream
            val i = DataInputStream(s.inputStream)
            o.write(ByteBuffer.allocate(4).putInt(nodeId).array())
            o.flush()
            val rid = i.readInt()
            val link = Link(s, rid, outgoing, s.remoteDevice.address, i)
            if (!register(link)) {
                link.close()
                return
            }
            mine = link
            changed()
            pool.execute { writeLoop(link, o) }
            pool.execute { sendHello() }
            while (link.alive) {
                val n = i.readUnsignedShort()
                val b = ByteArray(n)
                i.readFully(b)
                onPacket(b, link)
            }
        } catch (e: Exception) {
        } finally {
            mine?.let { m ->
                m.close()
                synchronized(links) { links.remove(m) }
                changed()
            }
            try { s.close() } catch (e: Exception) {}
        }
    }

    private fun register(n: Link): Boolean {
        if (n.remoteId == nodeId) return false
        return synchronized(links) {
            val ex = links.firstOrNull { it.remoteId == n.remoteId }
            if (ex != null) {
                val ni = if (n.outgoing) nodeId else n.remoteId
                val ei = if (ex.outgoing) nodeId else ex.remoteId
                if (ni < ei) { links.remove(ex); ex.close(); links.add(n); true } else false
            } else if (links.size >= MAX_LINKS) false
            else { links.add(n); true }
        }
    }

    private fun writeLoop(l: Link, o: OutputStream) {
        try {
            while (l.alive) {
                val p = l.q.poll(1, TimeUnit.SECONDS) ?: continue
                o.write(p)
                o.flush()
            }
        } catch (e: Exception) {
            l.close()
        }
    }

    // ---------------------------------------------------------------- discovery (manual "link")

    fun search(): Boolean {
        val ad = adapter ?: return false
        if (!running || searching) return false
        searching = true
        synchronized(found) { found.clear() }
        val r = object : BroadcastReceiver() {
            @Suppress("DEPRECATION")
            override fun onReceive(c: Context, i: Intent) {
                if (i.action == BluetoothDevice.ACTION_FOUND) {
                    val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    if (d != null) synchronized(found) { found[d.address] = d }
                } else if (i.action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                    finishSearch()
                }
            }
        }
        recv = r
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(r, f, Context.RECEIVER_EXPORTED)
        else ctx.registerReceiver(r, f)
        if (!ad.startDiscovery()) { finishSearch(); return false }
        ui.postDelayed({ if (searching) { try { ad.cancelDiscovery() } catch (e: Exception) {} } }, 20000)
        changed()
        return true
    }

    private fun finishSearch() {
        recv?.let { try { ctx.unregisterReceiver(it) } catch (e: Exception) {} }
        recv = null
        if (!searching) return
        searching = false
        val list = synchronized(found) { found.values.toList() }
        list.take(14).forEach { tryConnect(it, true) }
        changed()
    }

    // ---------------------------------------------------------------- packets

    private fun roomOf(): Int {
        if (mode != 1 || passcode.isEmpty()) return 0
        val h = MessageDigest.getInstance("SHA-256").digest(("room:$passcode").toByteArray())
        return ((((h[0].toInt() and 0xFF) shl 8) or (h[1].toInt() and 0xFF)) or 1)
    }

    private fun key(): ByteArray {
        val p = passcode
        if (p != keyPass) {
            keyBytes = MessageDigest.getInstance("SHA-256").digest(("sc-radio:$p").toByteArray()).copyOf(16)
            keyPass = p
        }
        return keyBytes
    }

    private fun crypt(data: ByteArray, sender: Int, sq: Int): ByteArray {
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        val iv = ByteBuffer.allocate(16).putInt(sender).putInt(sq).array()
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key(), "AES"), IvParameterSpec(iv))
        return c.doFinal(data)
    }

    private fun nextSeq(): Int = synchronized(this) { seq++ }

    private fun wire(body: ByteArray): ByteArray {
        val f = ByteArray(body.size + 2)
        f[0] = (body.size shr 8).toByte()
        f[1] = body.size.toByte()
        System.arraycopy(body, 0, f, 2, body.size)
        return f
    }

    private fun flood(frame: ByteArray, except: Link?) {
        synchronized(links) { for (l in links) if (l !== except) l.q.offer(frame) }
    }

    private fun send(type: Int, payload: ByteArray, ttl: Int) {
        val room = roomOf()
        val s = nextSeq()
        val pl = if (room != 0) crypt(payload, nodeId, s) else payload
        val bb = ByteBuffer.allocate(13 + pl.size)
        bb.put(type.toByte()).put(channel.toByte()).put(ttl.toByte())
            .putShort(room.toShort()).putInt(nodeId).putInt(s).put(pl)
        flood(wire(bb.array()), null)
    }

    private fun sendHello() {
        if (!on || scanning) return
        send(T_HELLO, byteArrayOf(0x5C) + callsign.toByteArray(Charsets.UTF_8), TTL)
    }

    private fun firstSeen(sender: Int, sq: Int): Boolean {
        val k = (sender.toLong() shl 32) or (sq.toLong() and 0xFFFFFFFFL)
        return synchronized(seen) { if (seen.containsKey(k)) false else { seen[k] = true; true } }
    }

    private fun onPacket(b: ByteArray, from: Link) {
        if (b.size < 13) return
        val bb = ByteBuffer.wrap(b)
        val type = b[0].toInt() and 0xFF
        val ch = b[1].toInt() and 0xFF
        val ttl = b[2].toInt() and 0xFF
        val room = bb.getShort(3).toInt() and 0xFFFF
        val sender = bb.getInt(5)
        val sq = bb.getInt(9)
        if (sender == nodeId || !firstSeen(sender, sq)) return
        if (ttl > 1) {
            val r = b.copyOf()
            r[2] = (ttl - 1).toByte()
            flood(wire(r), from)
        }
        try { handle(type, ch, room, sender, sq, ttl, b.copyOfRange(13, b.size)) } catch (e: Exception) {}
    }

    private fun handle(type: Int, ch: Int, room: Int, sender: Int, sq: Int, ttl: Int, payload: ByteArray) {
        if (!on || room != roomOf()) return
        val audio = type == T_AUDIO || type == T_AUDIO16
        if (audio) { if (ch != channel && !scanning) return } else if (ch != channel) return
        val pl = if (room != 0) crypt(payload, sender, sq) else payload
        val hops = (TTL - ttl + 1).coerceAtLeast(1)
        when (type) {
            T_HELLO -> if (pl.isNotEmpty() && pl[0] == 0x5C.toByte()) {
                users[sender] = User(String(pl, 1, pl.size - 1, Charsets.UTF_8), now(), hops)
                changed()
            }
            T_AUDIO, T_AUDIO16 -> {
                if (ch != channel) {
                    channel = ch; scanning = false; users.clear(); save()
                }
                rx(type, sender, pl, if (type == T_AUDIO16) 1 else hops)
            }
            T_END -> if (rxActive && sender == rxSender) endRx()
            T_TEXT -> {
                val t = String(pl, Charsets.UTF_8)
                addLog(t)
                unread++
                tone(ToneGenerator.TONE_PROP_ACK, 120)
                changed()
                ui.post { onText?.invoke(t) }
            }
        }
    }

    // ---------------------------------------------------------------- receive audio

    private fun rx(type: Int, sender: Int, pl: ByteArray, hops: Int) {
        if (talking) return
        if (rxActive && sender != rxSender && now() - rxLast < 500) return
        rxSender = sender
        rxLast = now()
        rxHops = hops
        if (!rxActive) {
            rxActive = true
            rxName = ""
            if (opt[O_VIB]) buzz(45)
            changed()
        }
        if (rxName.isEmpty()) {
            val n = users[sender]?.name ?: ""
            if (n.isNotEmpty()) { rxName = n; changed() }
        }
        val pcm: ShortArray
        if (type == T_AUDIO16) {
            pcm = ShortArray(minOf(pl.size, FRAME)) { Ulaw.dec(pl[it]) }
        } else {
            val n = minOf(pl.size, LO)
            pcm = ShortArray(n * 2)
            for (i in 0 until n) {
                val a = Ulaw.dec(pl[i]).toInt()
                val b = if (i + 1 < n) Ulaw.dec(pl[i + 1]).toInt() else a
                pcm[2 * i] = a.toShort()
                pcm[2 * i + 1] = ((a + b) / 2).toShort()
            }
        }
        setLevel(pcm, pcm.size)
        if (!pq.offer(pcm)) { pq.poll(); pq.offer(pcm) }
    }

    private fun endRx() {
        rxActive = false
        level = 0f
        if (opt[O_SROG]) tone(ToneGenerator.TONE_PROP_ACK, 120)
        changed()
    }

    private fun setLevel(x: ShortArray, n: Int) {
        if (n == 0) return
        var s = 0.0
        for (i in 0 until n) { val v = x[i].toDouble(); s += v * v }
        level = (sqrt(s / n).toFloat() / 6000f).coerceIn(0f, 1f)
        val t = now()
        if (t - lastLvlUi > 90) { lastLvlUi = t; changed() }
    }

    private fun startPlayback(g: Int) {
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(min, RATE / 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        at.setVolume(volume / 10f)
        at.play()
        track = at
        pq.clear()
        pool.execute {
            var idle = true
            while (alive(g)) {
                val f = pq.poll(200, TimeUnit.MILLISECONDS)
                if (f == null) { idle = true; continue }
                if (idle) {
                    idle = false
                    val t0 = now()
                    while (pq.size < 3 && now() - t0 < 120) Thread.sleep(10)
                }
                try {
                    if (at.playState != AudioTrack.PLAYSTATE_PLAYING) at.play()
                    at.write(f, 0, f.size)
                } catch (e: Exception) {}
            }
        }
    }

    private fun stopPlayback() {
        pq.clear()
        track?.let {
            try { it.stop() } catch (e: Exception) {}
            try { it.release() } catch (e: Exception) {}
        }
        track = null
    }

    // ---------------------------------------------------------------- transmit audio

    /** 16 kHz only when every known radio on the channel is a direct neighbour of ours. */
    private fun hiNow(): Boolean {
        if (!opt[O_HIQ] || linkCount() == 0) return false
        val u = users.values
        return u.isNotEmpty() && u.all { it.hops == 1 }
    }

    fun startTx() {
        if (!on || talking || locked) return
        if (rxActive && now() - rxLast < 300) {
            busyUntil = now() + 900
            tone(ToneGenerator.TONE_PROP_NACK, 120)
            changed()
            return
        }
        rxActive = false
        scanning = false
        txGen++
        val mine = txGen
        talking = true
        changed()
        pool.execute { txLoop(mine) }
    }

    fun stopTx() { talking = false }

    private fun txLoop(mine: Int) {
        synchronized(micLock) {
            var rec: AudioRecord? = null
            var any = false
            try {
                if (mine == txGen && talking) {
                    val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    val r0 = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, RATE)
                    )
                    rec = r0
                    if (r0.state != AudioRecord.STATE_INITIALIZED) {
                        micErr = now() + 2500
                    } else {
                        r0.startRecording()
                        val shifter = PitchShifter(when (voice) { 1 -> 1.4f; 2 -> 0.72f; else -> 1f })
                        val enh = VoiceFx()
                        val buf = ShortArray(FRAME)
                        while (talking && on && mine == txGen) {
                            var n = 0
                            while (n < FRAME && talking && mine == txGen) {
                                val r = r0.read(buf, n, FRAME - n)
                                if (r <= 0) break
                                n += r
                            }
                            if (n == 0) break
                            if (n < FRAME) java.util.Arrays.fill(buf, n, FRAME, 0.toShort())
                            shifter.process(buf, FRAME)
                            if (opt[O_ENH]) enh.process(buf, FRAME)
                            setLevel(buf, FRAME)
                            if (hiNow()) {
                                send(T_AUDIO16, ByteArray(FRAME) { Ulaw.enc(buf[it].toInt()) }, 1)
                            } else {
                                send(T_AUDIO, ByteArray(LO) { i ->
                                    Ulaw.enc((buf[2 * i].toInt() + buf[2 * i + 1].toInt()) / 2)
                                }, TTL)
                            }
                            any = true
                            if (n < FRAME) break
                        }
                        if (any) send(T_END, byteArrayOf(0), TTL)
                    }
                }
            } catch (e: Exception) {
                micErr = now() + 2500
            } finally {
                try { rec?.stop() } catch (e: Exception) {}
                try { rec?.release() } catch (e: Exception) {}
            }
            if (mine == txGen) {
                talking = false
                level = 0f
                changed()
            }
            if (any && opt[O_SROG]) tone(ToneGenerator.TONE_PROP_ACK, 120)
        }
    }

    private fun tone(t: Int, ms: Int) {
        try {
            if (tg == null) tg = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tg?.startTone(t, ms)
        } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun buzz(ms: Long) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- background ticker

    private fun tickLoop(g: Int) {
        var n = 0
        while (alive(g)) {
            Thread.sleep(150)
            n++
            val t = now()
            if (rxActive && t - rxLast > 500) endRx()
            if (!talking && !rxActive && level != 0f) { level = 0f; changed() }
            if ((busyUntil > 0 && t < busyUntil + 300) || (micErr > 0 && t < micErr + 300)) changed()
            if (scanning && !rxActive && !talking) { channel = channel % 99 + 1; changed() }
            if (n % 27 == 0) {
                users.entries.removeIf { t - it.value.ts > 14000 }
                try { sendHello() } catch (e: Exception) {}
                changed()
            }
        }
    }
}
