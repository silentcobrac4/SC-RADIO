package com.sc.radio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor

/** G.711 mu-law: 16-bit sample <-> 1 byte. */
object Ulaw {
    private const val BIAS = 0x84
    private const val CLIP = 32635

    fun enc(sample: Int): Byte {
        var s = sample
        val sign = if (s < 0) { s = -s; 0x80 } else 0
        if (s > CLIP) s = CLIP
        s += BIAS
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (s and mask) == 0) { exp--; mask = mask shr 1 }
        val man = (s shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or man).inv().toByte()
    }

    fun dec(b: Byte): Short {
        val u = b.toInt().inv() and 0xFF
        val sign = u and 0x80
        val exp = (u shr 4) and 7
        val man = u and 0x0F
        var s = ((man shl 3) + BIAS) shl exp
        s -= BIAS
        return (if (sign != 0) -s else s).toShort()
    }
}

/** Real-time pitch shifter (two crossfaded delay taps). ratio 1 = unchanged. */
class PitchShifter(private val ratio: Float) {
    private val w = 512
    private val mask = 2047
    private val buf = FloatArray(2048)
    private var wp = 0
    private var phase = 0f

    fun process(x: ShortArray, n: Int) {
        if (ratio == 1f) return
        for (i in 0 until n) {
            buf[wp] = x[i].toFloat()
            val p2 = (phase + 0.5f) % 1f
            val y = tap(phase) * gain(phase) + tap(p2) * gain(p2)
            x[i] = y.coerceIn(-32768f, 32767f).toInt().toShort()
            wp = (wp + 1) and mask
            phase += (1f - ratio) / w
            if (phase >= 1f) phase -= 1f
            if (phase < 0f) phase += 1f
        }
    }

    private fun gain(p: Float): Float = 0.5f - 0.5f * cos(2.0 * PI * p).toFloat()

    private fun tap(p: Float): Float {
        val pos = wp - (p * w + 1f)
        val i0 = floor(pos).toInt()
        val fr = pos - i0
        val a = buf[i0 and mask]
        val b = buf[(i0 + 1) and mask]
        return a + (b - a) * fr
    }
}
