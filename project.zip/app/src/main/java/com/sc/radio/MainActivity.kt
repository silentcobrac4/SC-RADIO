package com.sc.radio

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity(), RadioView.Cb {
    private lateinit var view: RadioView
    private val theme0 = android.R.style.Theme_Material_Dialog_Alert

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)
        view = RadioView(this)
        view.cb = this
        view.keepScreenOn = true
        setContentView(view)
    }

    override fun onResume() {
        super.onResume()
        Engine.onChange = { view.invalidate() }
        Engine.onText = { toast(it, true) }
        view.invalidate()
    }

    override fun onPause() {
        Engine.onChange = null
        Engine.onText = null
        super.onPause()
    }

    private fun toast(s: String, long: Boolean = false) {
        Toast.makeText(this, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ power / permissions

    private fun needed(): List<String> {
        val l = ArrayList<String>()
        l.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    private fun missing(): List<String> =
        needed().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun powerOn() {
        val miss = missing()
        if (miss.isNotEmpty()) {
            requestPermissions(miss.toTypedArray(), 1)
            return
        }
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null) { toast("هذا الجهاز لا يدعم البلوتوث"); return }
        if (!ad.isEnabled) {
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 7)
            return
        }
        startForegroundService(Intent(this, RadioService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val core = listOf(Manifest.permission.RECORD_AUDIO)
        if (core.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } &&
            (Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
        ) powerOn() else toast("يلزم السماح بالميكروفون والبلوتوث لتشغيل الراديو", true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK) powerOn()
    }

    // ------------------------------------------------------------ radio callbacks

    override fun onPtt(down: Boolean) {
        if (down) Engine.startTx() else Engine.stopTx()
    }

    override fun onKey(id: String) {
        if (id == "power") {
            if (Engine.on) stopService(Intent(this, RadioService::class.java)) else powerOn()
            return
        }
        when (id) {
            "mode" -> { modeDialog(); return }
            "m" -> { menu(); return }
        }
        if (!Engine.on) { toast("شغّل الراديو أولاً"); return }
        when (id) {
            "up" -> Engine.step(1)
            "dn" -> Engine.step(-1)
            "plus" -> Engine.setVolume(Engine.volume + 1)
            "minus" -> Engine.setVolume(Engine.volume - 1)
            "scan" -> Engine.toggleScan()
            "users" -> usersDialog()
            "red" -> msgDialog()
        }
    }

    // ------------------------------------------------------------ dialogs

    private fun builder() = AlertDialog.Builder(this, theme0)

    private fun menu() {
        val items = arrayOf("الوضع: قريب / خاص", "تغيير الصوت", "ربط أجهزة جديدة", "الرسائل", "اسم الراديو", "عن التطبيق")
        builder().setTitle("القائمة").setItems(items) { _, i ->
            when (i) {
                0 -> modeDialog()
                1 -> voiceDialog()
                2 -> link()
                3 -> if (Engine.on) msgDialog() else toast("شغّل الراديو أولاً")
                4 -> nameDialog()
                5 -> about()
            }
        }.show()
    }

    private fun modeDialog() {
        val items = arrayOf("قريب NEARBY — مفتوح لكل من على نفس القناة", "خاص PRIVATE — قناة + كلمة سر (مشفّر)")
        builder().setTitle("الوضع").setItems(items) { _, i ->
            if (i == 0) Engine.setMode(0, "") else passDialog()
        }.show()
    }

    private fun passDialog() {
        val et = EditText(this)
        et.setText(Engine.passcode)
        et.hint = "كلمة السر"
        builder().setTitle("الوضع الخاص").setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty()) toast("اكتب كلمة سر") else Engine.setMode(1, t)
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun voiceDialog() {
        builder().setTitle("تغيير الصوت")
            .setSingleChoiceItems(arrayOf("NORMAL", "HI PITCH", "LOW PITCH"), Engine.voice) { d, i ->
                Engine.setVoice(i)
                d.dismiss()
            }.show()
    }

    private fun usersDialog() {
        val names = ArrayList<String>()
        names.add("● ${Engine.callsign} (أنا)")
        Engine.users.values.forEach { names.add("● " + it.name) }
        builder().setTitle("قناة ${Engine.channel}: ${names.size} | روابط مباشرة: ${Engine.linkCount()}")
            .setItems(names.toTypedArray(), null)
            .setPositiveButton("رسالة") { _, _ -> msgDialog() }
            .setNegativeButton("ربط أجهزة") { _, _ -> link() }
            .setNeutralButton("إغلاق", null).show()
    }

    private fun msgDialog() {
        val et = EditText(this)
        et.hint = "اكتب رسالة"
        val log = Engine.chatLog()
        builder().setTitle("الرسائل").setMessage(if (log.isEmpty()) "لا رسائل بعد" else log).setView(et)
            .setPositiveButton("إرسال") { _, _ -> Engine.sendText(et.text.toString()) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun nameDialog() {
        val et = EditText(this)
        et.setText(Engine.callsign)
        et.filters = arrayOf(InputFilter.LengthFilter(14))
        builder().setTitle("اسم الراديو").setView(et)
            .setPositiveButton("حفظ") { _, _ -> Engine.setCallsign(et.text.toString()) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun link() {
        if (!Engine.on) { toast("شغّل الراديو أولاً"); return }
        try {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            )
        } catch (e: Exception) {}
        if (Engine.search()) toast("جارٍ البحث عن أجهزة sc radio… اضغط \"ربط\" على الأجهزة الأخرى أيضاً", true)
        else toast("البحث يعمل الآن أو غير متاح")
    }

    private fun about() {
        builder().setTitle("sc radio 1.0.0")
            .setMessage("راديو لاسلكي عبر البلوتوث فقط، بدون إنترنت.\nحتى 10 أجهزة على نفس القناة، وكل جهاز يعيد بث الصوت للآخرين.\nالمدى نحو 10 إلى 30 متراً لكل قفزة بين جهازين.")
            .setPositiveButton("حسناً", null).show()
    }
}
