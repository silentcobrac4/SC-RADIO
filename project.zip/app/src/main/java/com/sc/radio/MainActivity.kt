package com.sc.radio

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity(), RadioView.Cb {
    private lateinit var view: RadioView
    private val theme0 = android.R.style.Theme_Material_Dialog_Alert

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)
        view = RadioView(this)
        view.cb = this
        view.keepScreenOn = true
        setContentView(view)
    }

    override fun onResume() {
        super.onResume()
        Engine.onChange = { view.invalidate() }
        Engine.onText = { toast(it, true) }
        view.invalidate()
    }

    override fun onPause() {
        Engine.onChange = null
        Engine.onText = null
        super.onPause()
    }

    private fun toast(s: String, long: Boolean = false) {
        Toast.makeText(this, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ power / permissions

    private fun needed(): List<String> {
        val l = ArrayList<String>()
        l.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    private fun missing(): List<String> =
        needed().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun powerOn() {
        val miss = missing()
        if (miss.isNotEmpty()) {
            requestPermissions(miss.toTypedArray(), 1)
            return
        }
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null) { toast("هذا الجهاز لا يدعم البلوتوث"); return }
        if (!ad.isEnabled) {
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 7)
            return
        }
        startForegroundService(Intent(this, RadioService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val core = listOf(Manifest.permission.RECORD_AUDIO)
        if (core.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } &&
            (Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
        ) powerOn() else toast("يلزم السماح بالميكروفون والبلوتوث لتشغيل الراديو", true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK) powerOn()
    }

    // ------------------------------------------------------------ radio callbacks

    override fun onPtt(down: Boolean) {
        if (down) Engine.startTx() else Engine.stopTx()
    }

    override fun onKey(id: String) {
        if (id == "power") {
            if (Engine.on) stopService(Intent(this, RadioService::class.java)) else powerOn()
            return
        }
        when (id) {
            "lockedhint" -> { toast("الراديو مقفل. اضغط مطولاً على زر القفل لفتحه"); return }
            "lock" -> {
                if (!Engine.locked) { Engine.stopTx(); Engine.locked = true; Engine.changed() }
                return
            }
            "mode" -> { modeDialog(); return }
            "m" -> { menu(); return }
            "lcd" -> { chanDialog(); return }
            "red" -> { openMessages(); return }
        }
        if (!Engine.on) { toast("شغّل الراديو أولاً"); return }
        when (id) {
            "up" -> Engine.step(1)
            "dn" -> Engine.step(-1)
            "plus" -> Engine.changeVolume(Engine.volume + 1)
            "minus" -> Engine.changeVolume(Engine.volume - 1)
            "scan" -> Engine.toggleScan()
            "users" -> usersDialog()
        }
    }

    override fun onLong(id: String) {
        when (id) {
            "m" -> saveFavDialog()
            "lock" -> { Engine.locked = false; Engine.changed(); toast("تم فتح القفل") }
        }
    }

    private fun openMessages() {
        startActivity(Intent(this, MessagesActivity::class.java))
    }

    // ------------------------------------------------------------ dialogs

    private fun builder() = AlertDialog.Builder(this, theme0)

    private fun chanDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.filters = arrayOf(InputFilter.LengthFilter(2))
        et.hint = "1 - 99"
        et.setSingleLine()
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        val go: (String) -> Unit = { s ->
            val n = s.toIntOrNull()
            if (n == null || n < 1 || n > 99) toast("اكتب رقماً من 1 إلى 99") else Engine.gotoChannel(n)
        }
        val d = builder().setTitle("رقم القناة").setView(et)
            .setPositiveButton("تم") { _, _ -> go(et.text.toString()) }
            .setNegativeButton("إلغاء", null).create()
        et.setOnEditorActionListener { _, _, _ -> go(et.text.toString()); d.dismiss(); true }
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
    }

    private fun menu() {
        val items = arrayOf(
            "القنوات المحفوظة", "الوضع: قريب / خاص", "تغيير الصوت", "ربط أجهزة جديدة",
            "الرسائل", "الإعدادات", "اسم الراديو", "عن التطبيق"
        )
        builder().setTitle("القائمة").setItems(items) { _, i ->
            when (i) {
                0 -> favsDialog()
                1 -> modeDialog()
                2 -> voiceDialog()
                3 -> link()
                4 -> openMessages()
                5 -> settingsDialog()
                6 -> nameDialog()
                7 -> about()
            }
        }.show()
    }

    private fun favsDialog() {
        val b = builder().setTitle("القنوات المحفوظة")
            .setPositiveButton("حفظ القناة الحالية") { _, _ -> saveFavDialog() }
            .setNegativeButton("إغلاق", null)
        if (Engine.favs.isEmpty()) {
            b.setMessage("لا توجد قنوات محفوظة بعد.\nاضغط مطولاً على زر M لحفظ القناة الحالية.").show()
            return
        }
        val names = Engine.favs.map {
            "★ " + it.name + "   (CH " + "%02d".format(it.ch) + (if (it.mode == 1) " · خاصة)" else ")")
        }
        val d = b.setItems(names.toTypedArray()) { _, i -> Engine.applyFav(i) }.create()
        d.show()
        d.listView?.setOnItemLongClickListener { _, _, pos, _ ->
            builder().setTitle("حذف القناة؟").setMessage(Engine.favs.getOrNull(pos)?.name ?: "")
                .setPositiveButton("حذف") { _, _ -> Engine.removeFav(pos); d.dismiss(); favsDialog() }
                .setNegativeButton("إلغاء", null).show()
            true
        }
    }

    private fun saveFavDialog() {
        val et = EditText(this)
        et.setText("")
        et.hint = "اسم القناة (مثال: العائلة)"
        et.setSingleLine()
        et.filters = arrayOf(InputFilter.LengthFilter(16))
        val d = builder().setTitle("حفظ القناة " + "%02d".format(Engine.channel)).setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                if (Engine.addFav(et.text.toString())) toast("تم الحفظ")
                else toast("وصلت للحد الأقصى (9 قنوات). احذف قناة أولاً")
            }
            .setNegativeButton("إلغاء", null).create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
    }

    private fun settingsDialog() {
        val labels = arrayOf(
            "تقوية الصوت وإزالة الضجيج",
            "جودة عالية 16 كيلوهرتز عند الاتصال المباشر",
            "نغمة التشغيل",
            "نغمة روجر عند انتهاء الكلام",
            "نقرة عند تغيير القناة",
            "ضوء LED الإرسال والاستقبال",
            "مؤشر مستوى الصوت",
            "توهج الراديو عند الاستقبال",
            "اهتزاز عند الاستقبال",
            "مؤشر قوة الاتصال",
            "زر القفل"
        )
        builder().setTitle("الإعدادات")
            .setMultiChoiceItems(labels, Engine.opt.copyOf()) { _, i, c -> Engine.setOpt(i, c) }
            .setPositiveButton("تم", null).show()
    }

    private fun modeDialog() {
        val items = arrayOf("قريب NEARBY — مفتوح لكل من على نفس القناة", "خاص PRIVATE — قناة + كلمة سر (مشفّر)")
        builder().setTitle("الوضع").setItems(items) { _, i ->
            if (i == 0) Engine.setMode(0, "") else passDialog()
        }.show()
    }

    private fun passDialog() {
        val et = EditText(this)
        et.setText(Engine.passcode)
        et.hint = "كلمة السر"
        builder().setTitle("الوضع الخاص").setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty()) toast("اكتب كلمة سر") else Engine.setMode(1, t)
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun voiceDialog() {
        builder().setTitle("تغيير الصوت")
            .setSingleChoiceItems(arrayOf("NORMAL", "HI PITCH", "LOW PITCH"), Engine.voice) { d, i ->
                Engine.chooseVoice(i)
                d.dismiss()
            }.show()
    }

    private fun usersDialog() {
        val names = ArrayList<String>()
        names.add("● ${Engine.callsign} (أنا)")
        Engine.users.values.forEach {
            names.add("● " + it.name + if (it.hops <= 1) "  — مباشر" else "  — عبر " + (it.hops - 1) + " وسيط")
        }
        builder().setTitle("قناة ${Engine.channel}: ${names.size} | روابط مباشرة: ${Engine.linkCount()}")
            .setItems(names.toTypedArray(), null)
            .setPositiveButton("رسائل") { _, _ -> openMessages() }
            .setNegativeButton("ربط أجهزة") { _, _ -> link() }
            .setNeutralButton("إغلاق", null).show()
    }

    private fun nameDialog() {
        val et = EditText(this)
        et.setText(Engine.callsign)
        et.filters = arrayOf(InputFilter.LengthFilter(14))
        builder().setTitle("اسم الراديو").setView(et)
            .setPositiveButton("حفظ") { _, _ -> Engine.renameSelf(et.text.toString()) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun link() {
        if (!Engine.on) { toast("شغّل الراديو أولاً"); return }
        try {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            )
        } catch (e: Exception) {}
        if (Engine.search()) toast("جارٍ البحث عن أجهزة sc radio… اضغط \"ربط\" على الأجهزة الأخرى أيضاً", true)
        else toast("البحث يعمل الآن أو غير متاح")
    }

    private fun about() {
        builder().setTitle("sc radio 1.2.0")
            .setMessage("راديو لاسلكي عبر البلوتوث فقط، بدون إنترنت.\nحتى 10 أجهزة على نفس القناة، وكل جهاز يعيد بث الصوت للآخرين.\nالمدى نحو 10 إلى 30 متراً لكل قفزة بين جهازين.")
            .setPositiveButton("حسناً", null).show()
    }
}
