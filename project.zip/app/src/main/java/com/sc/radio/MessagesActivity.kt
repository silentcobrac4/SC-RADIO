package com.sc.radio

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Full-screen chat for the current channel. */
class MessagesActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var sv: ScrollView
    private lateinit var title: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val pad = (12 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.fitsSystemWindows = true

        title = TextView(this)
        title.setTextColor(0xFF3DDC84.toInt())
        title.textSize = 18f
        title.setPadding(pad, pad, pad, pad)

        sv = ScrollView(this)
        tv = TextView(this)
        tv.setTextColor(0xFFE6E6E6.toInt())
        tv.textSize = 16f
        tv.setPadding(pad, pad, pad, pad)
        sv.addView(tv)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val et = EditText(this)
        et.hint = "اكتب رسالة"
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.GRAY)
        val btn = Button(this)
        btn.text = "إرسال"
        btn.setOnClickListener {
            val t = et.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener
            if (!Engine.on) {
                Toast.makeText(this, "شغّل الراديو أولاً", Toast.LENGTH_SHORT).show()
            } else {
                Engine.sendText(t)
                et.setText("")
                refresh()
            }
        }
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn)

        root.addView(title)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root)
    }

    private fun refresh() {
        title.text = "الرسائل — قناة " + "%02d".format(Engine.channel)
        val all = Engine.chatAll()
        tv.text = if (all.isEmpty()) "لا رسائل بعد" else all.replace("\n", "\n\n")
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onResume() {
        super.onResume()
        Engine.unread = 0
        Engine.onText = { Engine.unread = 0; refresh() }
        refresh()
        Engine.changed()
    }

    override fun onPause() {
        Engine.onText = null
        super.onPause()
    }
}
